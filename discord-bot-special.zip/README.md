# Discord Bot Special

Un bot de Discord mai serios, făcut în `discord.js`, cu funcții utile și chestii fun:

- slash commands
- welcome / leave messages
- auto-role la intrare
- sistem de leveling + leaderboard
- reminders în DM
- giveaway cu buton de participare
- ticket system cu butoane
- comenzi de moderare: clear / timeout / kick / ban
- poll, embed, avatar, userinfo, serverinfo, 8ball
- log simplu pentru acțiuni de moderare

## 1) Ce trebuie să faci în Discord Developer Portal

Intră aici: Discord Developer Portal.

1. `New Application`
2. dă-i un nume
3. intră la `Bot`
4. apasă `Reset Token` / `Copy Token`
5. activează `MESSAGE CONTENT INTENT` și `SERVER MEMBERS INTENT`
6. la `OAuth2 > URL Generator`
7. bifează:
   - `bot`
   - `applications.commands`
8. la bot permissions bifează ce ai nevoie:
   - Manage Messages
   - Kick Members
   - Ban Members
   - Moderate Members
   - Manage Channels
   - Send Messages
   - Read Message History
   - Embed Links
   - Add Reactions
   - View Channels
9. deschide linkul generat și invită botul pe server

## 2) Variabile de mediu

Copiază `.env.example` în `.env` și completează:

- `DISCORD_TOKEN` = tokenul botului
- `CLIENT_ID` = Application ID din General Information
- `GUILD_ID` = ID-ul serverului tău pentru slash commands instant
- `WELCOME_CHANNEL_ID` = canalul pentru welcome/leave
- `LOG_CHANNEL_ID` = canalul pentru loguri
- `TICKET_CATEGORY_ID` = categoria unde se creează ticket-ele
- `AUTOROLE_ID` = rolul dat automat membrilor noi

## 3) Cum pornești local

```bash
npm install
npm start
```

## 4) Unde îl hostezi gratis

### Varianta mea recomandată: Koyeb

E una dintre opțiunile gratuite actuale pentru un bot mic:

- Free Instance: `512MB RAM`, `0.1 vCPU`, `2GB SSD`
- limită: un free instance per organizație
- e bun pentru hobby / test, nu pentru producție mare

Pași:

1. urcă proiectul pe GitHub
2. intră în Koyeb și fă cont
3. `Create App`
4. conectezi repo-ul GitHub
5. runtime: Node.js
6. start command: `npm start`
7. la Environment Variables pui valorile din `.env`
8. deploy

### Alternativă: Render

Render oferă servicii gratuite pentru hobby/testing, dar pentru boți Discord trebuie urmărit tipul de serviciu și limitările free tier-ului.

### De evitat dacă vrei strict gratis pe termen lung: Railway

Railway are în prezent plan Free cu resurse gratuite limitate și are și plan Hobby plătit; nu mai este varianta "mereu gratis" clasică pentru toată lumea.

## 5) Comenzi

- `/help`
- `/ping`
- `/serverinfo`
- `/userinfo`
- `/avatar`
- `/poll`
- `/embed`
- `/remind`
- `/rank`
- `/leaderboard`
- `/giveaway`
- `/ticketpanel`
- `/clear`
- `/timeout`
- `/kick`
- `/ban`
- `/8ball`
- `/setwelcome`
- `/setleave`

## 6) Important

Acest bot folosește fișier local `data/db.json` pentru date. Asta e ok pentru test și început, dar pentru server mare e mai bine cu o bază de date reală.
