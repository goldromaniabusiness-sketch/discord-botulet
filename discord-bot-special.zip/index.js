const {
  Client,
  GatewayIntentBits,
  Partials,
  PermissionsBitField,
  ChannelType,
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  REST,
  Routes,
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  const raw = fs.readFileSync(envPath, 'utf8');
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const idx = trimmed.indexOf('=');
    if (idx === -1) continue;
    const key = trimmed.slice(0, idx).trim();
    const value = trimmed.slice(idx + 1).trim();
    if (!process.env[key]) process.env[key] = value;
  }
}

const CONFIG = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID,
  welcomeChannelId: process.env.WELCOME_CHANNEL_ID || null,
  logChannelId: process.env.LOG_CHANNEL_ID || null,
  ticketCategoryId: process.env.TICKET_CATEGORY_ID || null,
  autoRoleId: process.env.AUTOROLE_ID || null,
};

if (!CONFIG.token || !CONFIG.clientId) {
  console.error('Lipsesc DISCORD_TOKEN sau CLIENT_ID. Verifica .env sau variabilele de mediu.');
  process.exit(1);
}

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(
    DB_FILE,
    JSON.stringify(
      {
        levels: {},
        reminders: [],
        giveaways: [],
        settings: {},
      },
      null,
      2,
    ),
  );
}

function readDb() {
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch (error) {
    console.error('Nu am putut citi baza locală:', error);
    return { levels: {}, reminders: [], giveaways: [], settings: {} };
  }
}

function writeDb(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

function getGuildSettings(guildId) {
  const db = readDb();
  if (!db.settings[guildId]) {
    db.settings[guildId] = {
      welcomeMessage: 'Bine ai venit, {user}, pe **{server}**! Distracție plăcută 🚀',
      leaveMessage: '{user} a ieșit din server. Pa! 👋',
    };
    writeDb(db);
  }
  return db.settings[guildId];
}

function xpNeeded(level) {
  return 100 + level * 75;
}

function addXp(guildId, userId, amount) {
  const db = readDb();
  if (!db.levels[guildId]) db.levels[guildId] = {};
  if (!db.levels[guildId][userId]) {
    db.levels[guildId][userId] = { xp: 0, level: 0, lastMessageAt: 0 };
  }
  const profile = db.levels[guildId][userId];
  const now = Date.now();
  if (now - profile.lastMessageAt < 15000) return null;
  profile.lastMessageAt = now;
  profile.xp += amount;
  let leveledUp = false;
  while (profile.xp >= xpNeeded(profile.level)) {
    profile.xp -= xpNeeded(profile.level);
    profile.level += 1;
    leveledUp = true;
  }
  writeDb(db);
  return { ...profile, leveledUp };
}

function getLeaderboard(guildId) {
  const db = readDb();
  const levels = db.levels[guildId] || {};
  return Object.entries(levels)
    .map(([userId, data]) => ({ userId, ...data }))
    .sort((a, b) => b.level - a.level || b.xp - a.xp)
    .slice(0, 10);
}

function scheduleLoop(client) {
  setInterval(async () => {
    const db = readDb();
    const now = Date.now();

    const dueReminders = db.reminders.filter((r) => r.when <= now && !r.sent);
    for (const reminder of dueReminders) {
      try {
        const user = await client.users.fetch(reminder.userId);
        await user.send(`⏰ Reminder: **${reminder.text}**`);
        reminder.sent = true;
      } catch (error) {
        console.error('Reminder failed:', error.message);
      }
    }

    const dueGiveaways = db.giveaways.filter((g) => g.endsAt <= now && !g.ended);
    for (const giveaway of dueGiveaways) {
      try {
        const channel = await client.channels.fetch(giveaway.channelId);
        if (!channel) continue;
        const message = await channel.messages.fetch(giveaway.messageId);
        giveaway.ended = true;
        const users = [...new Set(giveaway.entries)].filter((id) => id !== client.user.id);
        const winnerId = users.length ? users[Math.floor(Math.random() * users.length)] : null;
        const endEmbed = EmbedBuilder.from(message.embeds[0] || new EmbedBuilder())
          .setTitle('🎉 Giveaway încheiat')
          .setDescription(
            winnerId
              ? `Premiu: **${giveaway.prize}**\nCâștigător: <@${winnerId}>\nParticipanți: **${users.length}**`
              : `Premiu: **${giveaway.prize}**\nNu a participat nimeni 😢`,
          )
          .setTimestamp(new Date());
        await message.edit({ embeds: [endEmbed], components: [] });
        await channel.send(
          winnerId
            ? `🎊 Felicitări <@${winnerId}>! Ai câștigat **${giveaway.prize}**`
            : `Giveaway-ul pentru **${giveaway.prize}** s-a terminat fără participanți.`,
        );
      } catch (error) {
        console.error('Giveaway finalize failed:', error.message);
      }
    }

    writeDb(db);
  }, 10000);
}

function parseDuration(input) {
  const match = /^([0-9]+)(s|m|h|d)$/i.exec(input);
  if (!match) return null;
  const value = Number(match[1]);
  const unit = match[2].toLowerCase();
  const map = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
  return value * map[unit];
}

async function logToChannel(guild, text) {
  const channelId = CONFIG.logChannelId;
  if (!channelId) return;
  const channel = guild.channels.cache.get(channelId) || (await guild.channels.fetch(channelId).catch(() => null));
  if (channel && channel.isTextBased()) await channel.send(text).catch(() => {});
}

const commands = [
  new SlashCommandBuilder().setName('help').setDescription('Afișează comenzile botului'),
  new SlashCommandBuilder().setName('ping').setDescription('Verifică latența botului'),
  new SlashCommandBuilder().setName('serverinfo').setDescription('Informații despre server'),
  new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Informații despre un utilizator')
    .addUserOption((opt) => opt.setName('user').setDescription('Utilizatorul').setRequired(false)),
  new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('Afișează avatarul unui utilizator')
    .addUserOption((opt) => opt.setName('user').setDescription('Utilizatorul').setRequired(false)),
  new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Creează un poll rapid')
    .addStringOption((opt) => opt.setName('question').setDescription('Întrebarea').setRequired(true)),
  new SlashCommandBuilder()
    .setName('embed')
    .setDescription('Trimite un embed cool')
    .addStringOption((opt) => opt.setName('title').setDescription('Titlu').setRequired(true))
    .addStringOption((opt) => opt.setName('text').setDescription('Text').setRequired(true)),
  new SlashCommandBuilder()
    .setName('remind')
    .setDescription('Setează un reminder')
    .addStringOption((opt) => opt.setName('time').setDescription('Ex: 10m, 2h, 1d').setRequired(true))
    .addStringOption((opt) => opt.setName('text').setDescription('Mesajul reminderului').setRequired(true)),
  new SlashCommandBuilder().setName('rank').setDescription('Vezi nivelul tău'),
  new SlashCommandBuilder().setName('leaderboard').setDescription('Top nivele pe server'),
  new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Creează un giveaway')
    .addStringOption((opt) => opt.setName('duration').setDescription('Ex: 30m, 2h, 1d').setRequired(true))
    .addStringOption((opt) => opt.setName('prize').setDescription('Premiul').setRequired(true)),
  new SlashCommandBuilder().setName('ticketpanel').setDescription('Creează panoul de ticket'),
  new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Șterge mesaje')
    .addIntegerOption((opt) => opt.setName('count').setDescription('1-100').setRequired(true)),
  new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Pune timeout unui membru')
    .addUserOption((opt) => opt.setName('user').setDescription('Membrul').setRequired(true))
    .addStringOption((opt) => opt.setName('duration').setDescription('Ex: 10m, 1h, 1d').setRequired(true))
    .addStringOption((opt) => opt.setName('reason').setDescription('Motiv').setRequired(false)),
  new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Dă kick unui membru')
    .addUserOption((opt) => opt.setName('user').setDescription('Membrul').setRequired(true))
    .addStringOption((opt) => opt.setName('reason').setDescription('Motiv').setRequired(false)),
  new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Dă ban unui membru')
    .addUserOption((opt) => opt.setName('user').setDescription('Membrul').setRequired(true))
    .addStringOption((opt) => opt.setName('reason').setDescription('Motiv').setRequired(false)),
  new SlashCommandBuilder().setName('8ball').setDescription('Întreabă bila magică')
    .addStringOption((opt) => opt.setName('question').setDescription('Întrebarea').setRequired(true)),
  new SlashCommandBuilder()
    .setName('setwelcome')
    .setDescription('Setează mesajul de bun venit')
    .addStringOption((opt) => opt.setName('text').setDescription('Folosește {user} și {server}').setRequired(true)),
  new SlashCommandBuilder()
    .setName('setleave')
    .setDescription('Setează mesajul de ieșire')
    .addStringOption((opt) => opt.setName('text').setDescription('Folosește {user} și {server}').setRequired(true)),
].map((c) => c.toJSON());

async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(CONFIG.token);
  if (CONFIG.guildId) {
    await rest.put(Routes.applicationGuildCommands(CONFIG.clientId, CONFIG.guildId), { body: commands });
    console.log('Slash commands încărcate pe guild.');
  } else {
    await rest.put(Routes.applicationCommands(CONFIG.clientId), { body: commands });
    console.log('Slash commands globale încărcate.');
  }
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel],
});

client.once('ready', async () => {
  console.log(`Bot online ca ${client.user.tag}`);
  scheduleLoop(client);
});

client.on('guildMemberAdd', async (member) => {
  if (CONFIG.autoRoleId) {
    await member.roles.add(CONFIG.autoRoleId).catch(() => {});
  }
  if (!CONFIG.welcomeChannelId) return;
  const channel = member.guild.channels.cache.get(CONFIG.welcomeChannelId);
  if (!channel || !channel.isTextBased()) return;
  const settings = getGuildSettings(member.guild.id);
  const text = settings.welcomeMessage
    .replaceAll('{user}', `<@${member.id}>`)
    .replaceAll('{server}', member.guild.name);
  await channel.send(text).catch(() => {});
});

client.on('guildMemberRemove', async (member) => {
  if (!CONFIG.welcomeChannelId) return;
  const channel = member.guild.channels.cache.get(CONFIG.welcomeChannelId);
  if (!channel || !channel.isTextBased()) return;
  const settings = getGuildSettings(member.guild.id);
  const text = settings.leaveMessage
    .replaceAll('{user}', `**${member.user.tag}**`)
    .replaceAll('{server}', member.guild.name);
  await channel.send(text).catch(() => {});
});

client.on('messageCreate', async (message) => {
  if (!message.guild || message.author.bot) return;
  const result = addXp(message.guild.id, message.author.id, 15 + Math.floor(Math.random() * 11));
  if (result?.leveledUp) {
    await message.channel.send(`🔥 ${message.author}, ai urcat la nivelul **${result.level}**!`);
  }
});

client.on('interactionCreate', async (interaction) => {
  if (interaction.isButton()) {
    if (interaction.customId === 'join_giveaway') {
      const db = readDb();
      const giveaway = db.giveaways.find((g) => g.messageId === interaction.message.id && !g.ended);
      if (!giveaway) return interaction.reply({ content: 'Giveaway-ul nu mai este activ.', ephemeral: true });
      if (!giveaway.entries.includes(interaction.user.id)) giveaway.entries.push(interaction.user.id);
      writeDb(db);
      return interaction.reply({ content: 'Te-ai înscris în giveaway! 🎉', ephemeral: true });
    }

    if (interaction.customId === 'open_ticket') {
      const guild = interaction.guild;
      const existing = guild.channels.cache.find((c) => c.name === `ticket-${interaction.user.id}`);
      if (existing) {
        return interaction.reply({ content: `Ai deja ticket: ${existing}`, ephemeral: true });
      }
      const channel = await guild.channels.create({
        name: `ticket-${interaction.user.id}`,
        type: ChannelType.GuildText,
        parent: CONFIG.ticketCategoryId || null,
        permissionOverwrites: [
          { id: guild.roles.everyone.id, deny: [PermissionsBitField.Flags.ViewChannel] },
          { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] },
          { id: client.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ManageChannels] },
        ],
      });
      const closeRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('close_ticket').setLabel('Închide ticket').setStyle(ButtonStyle.Danger),
      );
      await channel.send({
        content: `Salut <@${interaction.user.id}>! Scrie aici problema ta.`,
        components: [closeRow],
      });
      return interaction.reply({ content: `Ți-am creat ticket-ul: ${channel}`, ephemeral: true });
    }

    if (interaction.customId === 'close_ticket') {
      await interaction.reply({ content: 'Ticket închis în 5 secunde...', ephemeral: true });
      setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
      return;
    }
  }

  if (!interaction.isChatInputCommand()) return;

  const name = interaction.commandName;
  const memberPerms = interaction.memberPermissions;
  const guild = interaction.guild;

  try {
    if (name === 'help') {
      const embed = new EmbedBuilder()
        .setTitle('🤖 Comenzi disponibile')
        .setDescription([
          '`/help`, `/ping`, `/serverinfo`, `/userinfo`, `/avatar`',
          '`/poll`, `/embed`, `/remind`, `/8ball`',
          '`/rank`, `/leaderboard`, `/giveaway`',
          '`/ticketpanel`, `/clear`, `/timeout`, `/kick`, `/ban`',
          '`/setwelcome`, `/setleave`',
        ].join('\n'))
        .setFooter({ text: 'Bot special by ChatGPT' });
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (name === 'ping') {
      return interaction.reply(`🏓 Pong! ${client.ws.ping}ms`);
    }

    if (name === 'serverinfo') {
      const embed = new EmbedBuilder()
        .setTitle(`📌 ${guild.name}`)
        .addFields(
          { name: 'Membri', value: String(guild.memberCount), inline: true },
          { name: 'Canale', value: String(guild.channels.cache.size), inline: true },
          { name: 'Roluri', value: String(guild.roles.cache.size), inline: true },
        )
        .setThumbnail(guild.iconURL())
        .setTimestamp(new Date(guild.createdTimestamp));
      return interaction.reply({ embeds: [embed] });
    }

    if (name === 'userinfo') {
      const user = interaction.options.getUser('user') || interaction.user;
      const member = await guild.members.fetch(user.id);
      const embed = new EmbedBuilder()
        .setTitle(`👤 ${user.tag}`)
        .setThumbnail(user.displayAvatarURL({ size: 512 }))
        .addFields(
          { name: 'ID', value: user.id },
          { name: 'Cont creat', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F>` },
          { name: 'Intrat pe server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>` },
        );
      return interaction.reply({ embeds: [embed] });
    }

    if (name === 'avatar') {
      const user = interaction.options.getUser('user') || interaction.user;
      const embed = new EmbedBuilder().setTitle(`🖼️ Avatar - ${user.tag}`).setImage(user.displayAvatarURL({ size: 1024 }));
      return interaction.reply({ embeds: [embed] });
    }

    if (name === 'poll') {
      const question = interaction.options.getString('question', true);
      const embed = new EmbedBuilder().setTitle('📊 Poll').setDescription(question);
      const msg = await interaction.reply({ embeds: [embed], fetchReply: true });
      await msg.react('👍');
      await msg.react('👎');
      return;
    }

    if (name === 'embed') {
      const title = interaction.options.getString('title', true);
      const text = interaction.options.getString('text', true);
      const embed = new EmbedBuilder().setTitle(title).setDescription(text).setColor(0x5865f2);
      return interaction.reply({ embeds: [embed] });
    }

    if (name === 'remind') {
      const duration = parseDuration(interaction.options.getString('time', true));
      const text = interaction.options.getString('text', true);
      if (!duration) return interaction.reply({ content: 'Format invalid. Exemplu: 10m / 2h / 1d', ephemeral: true });
      const db = readDb();
      db.reminders.push({ userId: interaction.user.id, text, when: Date.now() + duration, sent: false });
      writeDb(db);
      return interaction.reply({ content: `Reminder setat peste **${interaction.options.getString('time', true)}**.`, ephemeral: true });
    }

    if (name === 'rank') {
      const db = readDb();
      const profile = db.levels[guild.id]?.[interaction.user.id] || { level: 0, xp: 0 };
      return interaction.reply(`🏅 ${interaction.user}: nivel **${profile.level}**, XP **${profile.xp}/${xpNeeded(profile.level)}**`);
    }

    if (name === 'leaderboard') {
      const top = getLeaderboard(guild.id);
      if (!top.length) return interaction.reply('Nu există date încă.');
      const lines = top.map((u, i) => `**${i + 1}.** <@${u.userId}> — lvl ${u.level} (${u.xp} XP)`).join('\n');
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle('🏆 Leaderboard').setDescription(lines)] });
    }

    if (name === 'giveaway') {
      if (!memberPerms.has(PermissionsBitField.Flags.ManageGuild)) {
        return interaction.reply({ content: 'Ai nevoie de Manage Server.', ephemeral: true });
      }
      const durationRaw = interaction.options.getString('duration', true);
      const prize = interaction.options.getString('prize', true);
      const duration = parseDuration(durationRaw);
      if (!duration) return interaction.reply({ content: 'Durată invalidă.', ephemeral: true });
      const joinRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('join_giveaway').setLabel('Participă').setStyle(ButtonStyle.Success).setEmoji('🎉'),
      );
      const embed = new EmbedBuilder()
        .setTitle('🎁 Giveaway nou')
        .setDescription(`Premiu: **${prize}**\nSe termină: <t:${Math.floor((Date.now() + duration) / 1000)}:R>\nApasă pe buton ca să participi.`);
      const msg = await interaction.reply({ embeds: [embed], components: [joinRow], fetchReply: true });
      const db = readDb();
      db.giveaways.push({
        channelId: interaction.channelId,
        messageId: msg.id,
        prize,
        endsAt: Date.now() + duration,
        entries: [],
        ended: false,
      });
      writeDb(db);
      return;
    }

    if (name === 'ticketpanel') {
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('open_ticket').setLabel('Deschide ticket').setStyle(ButtonStyle.Primary),
      );
      const embed = new EmbedBuilder()
        .setTitle('🎫 Support Ticket')
        .setDescription('Apasă pe buton pentru a deschide un ticket privat cu staff-ul.');
      return interaction.reply({ embeds: [embed], components: [row] });
    }

    if (name === 'clear') {
      if (!memberPerms.has(PermissionsBitField.Flags.ManageMessages)) {
        return interaction.reply({ content: 'Ai nevoie de Manage Messages.', ephemeral: true });
      }
      const count = interaction.options.getInteger('count', true);
      if (count < 1 || count > 100) return interaction.reply({ content: 'Alege un număr între 1 și 100.', ephemeral: true });
      await interaction.channel.bulkDelete(count, true);
      await interaction.reply({ content: `Am șters ${count} mesaje.`, ephemeral: true });
      await logToChannel(guild, `🧹 ${interaction.user.tag} a șters ${count} mesaje în ${interaction.channel}`);
      return;
    }

    if (name === 'timeout') {
      if (!memberPerms.has(PermissionsBitField.Flags.ModerateMembers)) {
        return interaction.reply({ content: 'Ai nevoie de Moderate Members.', ephemeral: true });
      }
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason') || 'Fără motiv';
      const durationRaw = interaction.options.getString('duration', true);
      const duration = parseDuration(durationRaw);
      if (!duration) return interaction.reply({ content: 'Durată invalidă.', ephemeral: true });
      const target = await guild.members.fetch(user.id);
      await target.timeout(duration, reason);
      await interaction.reply(`⏳ ${user.tag} a primit timeout pentru **${durationRaw}**.`);
      await logToChannel(guild, `⏳ ${interaction.user.tag} a dat timeout lui ${user.tag} pentru ${durationRaw}. Motiv: ${reason}`);
      return;
    }

    if (name === 'kick') {
      if (!memberPerms.has(PermissionsBitField.Flags.KickMembers)) {
        return interaction.reply({ content: 'Ai nevoie de Kick Members.', ephemeral: true });
      }
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason') || 'Fără motiv';
      const target = await guild.members.fetch(user.id);
      await target.kick(reason);
      await interaction.reply(`👢 ${user.tag} a primit kick.`);
      await logToChannel(guild, `👢 ${interaction.user.tag} a dat kick lui ${user.tag}. Motiv: ${reason}`);
      return;
    }

    if (name === 'ban') {
      if (!memberPerms.has(PermissionsBitField.Flags.BanMembers)) {
        return interaction.reply({ content: 'Ai nevoie de Ban Members.', ephemeral: true });
      }
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason') || 'Fără motiv';
      await guild.members.ban(user.id, { reason });
      await interaction.reply(`🔨 ${user.tag} a primit ban.`);
      await logToChannel(guild, `🔨 ${interaction.user.tag} a dat ban lui ${user.tag}. Motiv: ${reason}`);
      return;
    }

    if (name === '8ball') {
      const question = interaction.options.getString('question', true);
      const answers = [
        'Da, clar.',
        'Nu prea cred.',
        'Mai întreabă o dată.',
        '100% da.',
        'Șanse mici.',
        'Absolut.',
        'Mai bine nu.',
        'Semnele spun că da.',
      ];
      const reply = answers[Math.floor(Math.random() * answers.length)];
      return interaction.reply(`🎱 **Întrebare:** ${question}\n**Răspuns:** ${reply}`);
    }

    if (name === 'setwelcome' || name === 'setleave') {
      if (!memberPerms.has(PermissionsBitField.Flags.ManageGuild)) {
        return interaction.reply({ content: 'Ai nevoie de Manage Server.', ephemeral: true });
      }
      const text = interaction.options.getString('text', true);
      const db = readDb();
      if (!db.settings[guild.id]) db.settings[guild.id] = {};
      if (name === 'setwelcome') db.settings[guild.id].welcomeMessage = text;
      if (name === 'setleave') db.settings[guild.id].leaveMessage = text;
      writeDb(db);
      return interaction.reply({ content: 'Mesaj salvat.', ephemeral: true });
    }
  } catch (error) {
    console.error(error);
    if (interaction.replied || interaction.deferred) {
      return interaction.followUp({ content: 'A apărut o eroare.', ephemeral: true }).catch(() => {});
    }
    return interaction.reply({ content: 'A apărut o eroare.', ephemeral: true }).catch(() => {});
  }
});

registerCommands()
  .then(() => client.login(CONFIG.token))
  .catch((error) => {
    console.error('Pornirea a eșuat:', error);
    process.exit(1);
  });
